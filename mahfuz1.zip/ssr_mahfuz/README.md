
Just install dependencies, build the app and run the express server:

```
yarn install
yarn run build
yarn run server
```

