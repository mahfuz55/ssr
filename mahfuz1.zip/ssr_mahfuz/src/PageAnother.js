import React from 'react';

export default () => (
    <div>This is for another page.</div>
);
