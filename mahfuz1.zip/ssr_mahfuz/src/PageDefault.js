import React from 'react';

export default () => (
    <div>This is for the main page.</div>
);
