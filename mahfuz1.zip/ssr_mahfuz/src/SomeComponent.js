import React from 'react';

export default () => (
    <p>Hi, I'm async.</p>
);
